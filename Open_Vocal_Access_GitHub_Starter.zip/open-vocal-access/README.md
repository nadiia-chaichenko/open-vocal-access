# Open Vocal Access

**An early-stage, open-source toolkit for discovering classical vocal repertoire.**

Open Vocal Access explores how structured repertoire data and accessible digital tools can make vocal study easier for singers, teachers, and independent learners. The project begins with a small, searchable catalogue of opera arias and is intended to grow through carefully reviewed contributions.

## What works today

- Browse sample opera repertoire by **language**, **voice type**, or **keyword**.
- Use the catalogue without installing any Python packages.
- Export filtered records to JSON for use in other tools.
- Edit the human-readable CSV catalogue to propose additions.

**Project status:** prototype. The sample catalogue is intentionally small; this project has no claimed adoption, external contributors, or downstream users at launch.

## Quick start

Requires Python 3.10 or newer. Open a terminal in the project folder:

```bash
python3 vocal_access.py
python3 vocal_access.py --voice "mezzo-soprano" --language French
python3 vocal_access.py --keyword Carmen --json
```

Run the automated tests:

```bash
python3 -m unittest discover -s tests -v
```

## Why this exists

Classical vocal study requires singers to consult repertoire lists, language resources, scores, and casting conventions scattered across many sources. This project experiments with a transparent, reusable metadata format. It does **not** prescribe fach or replace advice from a qualified teacher or vocal coach.

## Roadmap (proposals, not completed features)

1. Add editorial citations and contributor-reviewed repertoire entries.
2. Develop simple pronunciation and multilingual metadata conventions.
3. Improve keyboard and screen-reader access through a lightweight interface.
4. Add exports compatible with existing open music technology projects.

## Contributing

Corrections and small, well-documented suggestions are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md). Please do not upload copyrighted scores, lyrics, recordings, or non-free translations without permission.

## Licensing and credits

Source code and original metadata in this repository are distributed under the [MIT License](LICENSE). Titles, factual information, composer and opera names are not asserted to be proprietary. Example voice classifications are educational approximations and vary by edition, performer, and casting tradition.

**Initiated by:** Nadiia Chaichenko, classical vocalist and postgraduate music student.

This initial software prototype was prepared with AI assistance and should be reviewed, tested, and maintained by the project owner. It is not affiliated with or endorsed by the Royal College of Music, GitHub, or Anthropic.
